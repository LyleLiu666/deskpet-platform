"""DeskPet Platform SDK."""
